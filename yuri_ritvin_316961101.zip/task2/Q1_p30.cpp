1.		main: k = 4
		f: k = 4
		main: k = 4

2. Complie will fail, its void function!


3.	main: k = 4
	g: k = 4
	g: k = 7
	main: k = 4


4.	main: k = 4
	g: k = 4
	g: k = 7
	main: k = 7

5.	h: k = 5
	h: k = 6295968

6.	h1: k = 12
	return 1

7. Complie will wail, int was declared twice
